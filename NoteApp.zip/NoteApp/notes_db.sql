create database notes_db;

